const KEY="my-vocabulary-data-v1";
let data=load(), page="home", quizWord=null, quizAnswered=false, quizChoices=[];
function fresh(){return {words:[],total:0,correct:0}}
function load(){try{return JSON.parse(localStorage.getItem(KEY))||fresh()}catch{return fresh()}}
function save(){localStorage.setItem(KEY,JSON.stringify(data));render()}
function go(p){page=p;document.querySelectorAll(".page").forEach(x=>x.classList.toggle("hidden",x.id!==p));document.querySelectorAll("nav button").forEach(x=>x.classList.toggle("active",x.dataset.page===p));if(p==="quiz")startQuiz();render()}
document.querySelectorAll("nav button").forEach(b=>b.addEventListener("click",()=>go(b.dataset.page)));
document.getElementById("wordForm").addEventListener("submit",e=>{
 e.preventDefault();const word=english.value.trim(),meaning=document.getElementById("meaning").value.trim(),example=document.getElementById("example").value.trim();
 if(data.words.some(w=>w.word.toLowerCase()===word.toLowerCase())){addMessage.textContent="この単語は登録済みです。";return}
 data.words.push({id:Date.now()+Math.random(),word,meaning,example,correct:0,wrong:0});e.target.reset();addMessage.textContent="登録しました。";save();go("words");
});
function removeWord(id){if(!confirm("この単語を削除しますか？"))return;data.words=data.words.filter(w=>w.id!==id);save()}
function render(){
 count.textContent=data.words.length;weakCount.textContent=data.words.filter(w=>w.wrong>0).length;
 accuracy.textContent=(data.total?Math.round(data.correct/data.total*100):0)+"%";
 progress.style.width=(data.total?data.correct/data.total*100:0)+"%";
 record.textContent=`テスト ${data.total}回 / 正解 ${data.correct}回`;
 wordList.innerHTML=data.words.length?data.words.map(w=>`<article class="word"><div class="word-top"><strong>${esc(w.word)}</strong>${w.wrong?'<span class="tag">要復習</span>':''}</div><div>${esc(w.meaning)}</div>${w.example?`<div class="example">${esc(w.example)}</div>`:''}<div class="muted">正解 ${w.correct}回 / 不正解 ${w.wrong}回</div><div class="actions"><button class="danger" onclick="removeWord('${w.id}')">削除</button></div></article>`).join(""):'<div class="notice">まだ単語がありません。「登録」から追加してください。</div>';
 const weak=data.words.filter(w=>w.wrong>0);
 weakList.innerHTML=weak.length?weak.map(w=>`<article class="word"><strong>${esc(w.word)}</strong><div>${esc(w.meaning)}</div><div class="muted">不正解 ${w.wrong}回 / 正解 ${w.correct}回</div></article>`).join(""):'<div class="notice">苦手単語はまだありません。テストで間違えた単語がここに追加されます。</div>';
}
function startQuiz(){
 quizAnswered=false;
 if(data.words.length<4){quizArea.innerHTML=`<div class="notice">4択テストには最低4単語が必要です。現在 ${data.words.length} / 4 単語です。</div><button class="primary" onclick="go('add')">単語を登録する</button>`;return}
 const weak=data.words.filter(w=>w.wrong>0);
 const pool=weak.length?weak:data.words;
 quizWord=pool[Math.floor(Math.random()*pool.length)];
 quizChoices=[quizWord,...data.words.filter(w=>w.id!==quizWord.id).sort(()=>Math.random()-.5).slice(0,3)].sort(()=>Math.random()-.5);
 showQuestion();
}
function showQuestion(){
 quizArea.innerHTML=`<div class="muted">この英単語の意味は？</div><div class="question"><div class="english">${esc(quizWord.word)}</div></div>`+
 quizChoices.map((w,i)=>`<button class="choice" id="choice${i}" onclick="answer('${w.id}')">${String.fromCharCode(65+i)}　${esc(w.meaning)}</button>`).join("")+
 `<div id="result"></div>`;
}
function answer(id){
 if(quizAnswered)return;quizAnswered=true;const ok=String(quizWord.id)===String(id);data.total++;
 if(ok){data.correct++;quizWord.correct++}else quizWord.wrong++;
 quizChoices.forEach((w,i)=>{const b=document.getElementById("choice"+i);b.disabled=true;if(w.id===quizWord.id)b.classList.add("correct");else if(String(w.id)===String(id))b.classList.add("wrong")});
 result.innerHTML=`<div class="notice"><b>${ok?"正解！":"不正解"}</b>${ok?"":`<br>正解：${esc(quizWord.word)} = ${esc(quizWord.meaning)}`}</div><button class="primary" onclick="startQuiz()">次の問題へ</button>`;
 localStorage.setItem(KEY,JSON.stringify(data));render();
}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
render();
if("serviceWorker" in navigator && location.protocol.startsWith("http"))window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
